
public class TextNote {
	
	String text;

}
