import java.util.ArrayList;

public class NoteStore {
	
	//Creates the ArrayLists
	ArrayList<TextNote> AllTextNotes = new ArrayList<TextNote>();
	ArrayList<TextAndImageNote> AllTextAndImageNotes = new ArrayList<TextAndImageNote>();

	public void storeNote(String Text) {
		TextNote ref1 = new TextNote();
		ref1.text = Text;
		AllTextNotes.add(ref1);
	}

	public void storeNote(String Text, String ImageURL) {
		TextAndImageNote ref2 = new TextAndImageNote();
		ref2.text = Text;
		ref2.imageURL = ImageURL;
		AllTextAndImageNotes.add(ref2);
	}

	public ArrayList<TextNote> getAllTextNotes() {
		
		return AllTextNotes;
	}

	public ArrayList<TextAndImageNote> getAllTextAndImageNotes() {
		return AllTextAndImageNotes;

	}

}
