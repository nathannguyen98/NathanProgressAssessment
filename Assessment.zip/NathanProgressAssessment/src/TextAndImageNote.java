
public class TextAndImageNote {

	String text;
	String imageURL;
	
}
