

public class Launcher {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// First note
		 NoteStore newItems = new NoteStore();
		newItems.storeNote(
				"Java is a set of computer software and specifications developed by James Gosling and Sun Microsystems");
		newItems.storeNote("Few books to read - Ikigai, How to win friends and influence people");
		newItems.storeNote("The shopping list on my fridge", "//foo/bar1/bar2/imgset1.jpg");
		newItems.storeNote("The size label of Jack's shirt", "//foo/bar1/bar2/imgset2.jpg");
		
		
		displayTextNotes(newItems);
		displayTextAndImageNotes(newItems);
		
	}

	public static void displayTextNotes(NoteStore alltextnotes) {
		System.out.println(alltextnotes.getAllTextNotes());
	}

	public static void displayTextAndImageNotes(NoteStore alltextandimagenotes) {
		System.out.println(alltextandimagenotes.getAllTextAndImageNotes());
	}
}
